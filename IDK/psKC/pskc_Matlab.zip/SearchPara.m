clear 
load('4C.mat') 
figure
gscatter(data(:,1),data(:,2),class)

t=100; 
v=0.1; 

psilist=[2 4 6 8 16 24 32 48 64 80 100 200 250 500 750 1000 2000 2500 5000 10000];
taulist=[0.1 0.05 0.01 0.005 0.001 0.0005 0.0001 0.00005 0.00001 0.000005 0.75 0.5 0.4 0.3 0.25 0.2 0.15 0.1 0.075 0.05];

AA=[];
psilist=psilist(psilist<size(data,1));
for pp=1:length(psilist)   
    
    for tt=1:length(taulist)
        psi=psilist(pp);
        tau=taulist(tt);
        
        [Tclass,~,~] =  pskc(data,psi,t,tau,v);
        [AMI]=ami(class,Tclass+1);
        
        AA(pp,tt)=AMI;
    end
end
%% find the best parameters
[a,b]=find(AA==max(max(AA)));
psi=psilist(a);
tau=taulist(b);
[Tclass,Centre,ndata] =  pskc(data,psi,t,tau,v);
[AMI]=ami(class,Tclass+1);
%% plot the best result
figure
scatter(data(Centre,1),data(Centre,2),135,'bx')
hold on
gscatter(data(:,1),data(:,2),Tclass)
title(['AMI=' num2str(AMI)])
