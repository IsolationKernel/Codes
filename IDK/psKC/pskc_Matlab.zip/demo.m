clear
close all
load('4C.mat') 
figure
gscatter(data(:,1),data(:,2),class)

t=100; 
v=0.1; 
psi=500;
tau=0.0000001;
[Tclass,Centre,ndata] =  pskc(data,psi,t,tau,v);
[AMI]=ami(class,Tclass+1);% +1 is for Tclass=0
%% plot the best result
figure
scatter(data(Centre,1),data(Centre,2),135,'bx')
hold on
gscatter(data(:,1),data(:,2),Tclass)
title(['AMI=' num2str(AMI)])