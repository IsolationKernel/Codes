function [Tclass,Centre,ndata] = pskc(data,psi,t,tau,v)
[ndata] = SIKspace (data,data, psi, t); % IK feature space mapping- sparse matrix
% [ndata] = IKspace (data,data, psi, t); % full matrix
k=0; % class index
C={};
CD=1:size(data,1); 
D=[CD' ndata]; % add index in the first column 

while size(D,1)>1
    k=k+1;
    
    [~,x]=max(D(:,2:end)*sum(D(:,2:end),1)'./t./size(D,1)); % find the cluster centre
    
    C{k}=D(x,:);
    D(x,:)=[];
    
    [z,y]=max(D(:,2:end)*C{k}(:,2:end)'./t./size(D,1)); 
    
    C{k}=[ C{k}; D(y,:)];
    D(y,:)=[];
    
    r=(1-v)*z;
    if r<=tau
        disp('break')
        break
    end
    
    sizeC=length(x)+length(y);
    
    while r>tau
        S=D(:,2:end)*sum(C{k}(:,2:end),1)'./t./sizeC;
        [x,~]=find(S>r);
        C{k}=[ C{k}; D(x,:)];
        D(x,:)=[];
        r=(1-v)*r;
        sizeC=sizeC+length(x);
    end
end 

Tclass=zeros(size(data,1),1);

Centre=[];
for i=1:size(C,2)
    Tclass(C{i}(:,1))=i;
    Centre=[Centre;C{i}(1,1)];
end
end

